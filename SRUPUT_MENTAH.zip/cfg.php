<?php

$useragent = "xxxx";

$cookie = "xxxx";