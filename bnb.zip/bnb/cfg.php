<?php

$user_agen = "xnxx";
$cookie = "xnxx";

//Wallet Harus kaitkan dulu di web
$wallet = "xnxx";
