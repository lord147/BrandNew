<?php 

$trx_address = "xxx";

$user_agent = "xxx";

?>