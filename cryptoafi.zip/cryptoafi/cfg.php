<?
$cookie = "xxxxx";
$user_agent = "xxxxx";
/* WITHDRAW */
$wallet="xxxxx";
/**//**//**//**//**//**//**//*
1-BTC
2-LTC
3-DOGE
4-DASH
5-USDT
6-TRX
*//*INPUT NUMBER ONLY*/
$coin_number="xxxxx";
