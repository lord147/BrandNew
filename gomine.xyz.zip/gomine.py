# Script by Fikri AF
# I am like it
def main1():
	#------------------------------------------------------#
	adres=data.AddressTRX
	cooki=data.Cookie
	user_agent=data.ua
	#------------------------------------------------------#
	head={
	"Host": "gomine.xyz",
	"user-agent": user_agent,
	"cookie": cooki
	}
	data_start={
	"acc": adres,
	"reff": "7036",
	"login": ""
	}
	#------------------------------------------------------#
	print(f"""{bold}----------------------------------------------------
{green}Address TRX :
{yellow}{adres}{reset}
{bold}----------------------------------------------------""")
	#------------------------------------------------------#
	start=requests.get("https://gomine.xyz/user/home", headers=head).text
	if adres in start:
		print(f"{bold}{yellow}STARTING...")
		if "Someone already logged using this ip address. Your I.P Is:" in start:
			print(f"""{bold}:::::::::::::::::::::::::::
{bold}{yellow}🔺 Please Connect To VPN{reset}
{bold}:::::::::::::::::::::::::::""")
			exit()
		os.system("rm -f temp.txt")
	else:
		print(f"{bold}{red}GAGAL STARTING")
		exit()
	while True:
		#------------------------------------------------------#
		info=requests.get("https://gomine.xyz/user/pay", headers=head).text
		balance=BeautifulSoup(info, "html.parser").find("h2", attrs={"class": "text-center"}).get_text().replace("  TRX", "TRX")
		print(f"""{reset}{bold}----------------------------------------------------
{cyan}Saldo : {balance}{reset}
{bold}----------------------------------------------------{reset}""")
	    #------------------------------------------------------#
		for i in range(3):
			start1=requests.get("https://gomine.xyz/user/home", headers=head).text
			mining_now=BeautifulSoup(start1, "html.parser").findAll("script")[7]
			open("temp.txt", "w").write(str(mining_now))
			out=open("temp.txt", "r").readlines()[3].replace("var", "").replace("sec", "mining").replace(";", "")
		 	#------------------------------------------------------#
			mining=requests.get("https://gomine.xyz/user/home", headers=head).status_code
			if mining == 200:
				print(f"""{bold}{cyan}\n::::::::::::::::::::::::::::::::::::::::::\n\n{out}\n::::::::::::::::::::::::::::::::::::::::::\n{bold}{green}🔴 Gomine on running""")
				time.sleep(480)
			else:
				print(f"{bold}{magenta}>> Cookie is not working, Please restart script again !!")
				input(f"{yellow}Please capture again and get cookie{reset}")
				open("data.py", "w").write(" ")
				exit()
		claim=requests.get("https://gomine.xyz/inc/data.php", headers=head).text
		if claim != "Failed":
			print(f"{reset}{bold}----------------------------------------------------")
			print(f"{jam}{bold}{green} Claim Successfuly, Telah dikirim ke saldo gomine anda [✅]")
		else:
			print(f"{jam}{bold}{red} Claim Unsuccessful [❌]")

		#------------------------------------------------------#
def main2():
	import data
	#------------------------------------------------------#
	adres=data.AddressTRX
	cooki=data.Cookie
	user_agent=data.ua
	#------------------------------------------------------#
	head={
	"Host": "gomine.xyz",
	"user-agent": user_agent,
	"cookie": cooki
	}
	info=requests.get("https://gomine.xyz/user/pay", headers=head).text
	balance=BeautifulSoup(info, "html.parser").find("h2", attrs={"class": "text-center"}).get_text().replace("  TRX", "TRX")
	print(f"""{reset}{bold}----------------------------------------------------
{cyan}Saldo : {balance}{reset}
{bold}----------------------------------------------------{reset}""")
	print(f"""{bold}{green}
:::::::::::::::::::::::::::::
Minimum withdraw 0.01 TRX
Pastikan saldo anda mencukupi
:::::::::::::::::::::::::::::
{reset}""")
	amoun=input(f"{bold}{yellow}Withdraw berapa? [min. 0.01] : ")
	data_wd={
	"amount": amoun,
	"fpay": ""
	}
	gas_wd=requests.post("https://gomine.xyz/user/pay", data=data_wd, headers=head).text
	if "Successfully" in gas_wd:
		print(f"\n{jam}{bold}{cyan} {amoun} {white}TRX has been sent to {magenta}{adres}\n")
	else:
		print(f"\n{jam}{bold}{red} Withdraw gagal, Try to another time\n")
	input(f"{bold}{white}Press enter to restart script {reset}")
	os.system("python gomine.py")
	
if __name__=="__main__":
	try:
		#-------------------------------------------#
		reset='\u001b[0m'
		up='\u001b[{n}A'
		down='\u001b[{n}B'
		right='\u001b[{n}C'
		left='\u001b[{n}D'
		bold='\u001b[1m'
		underline='\u001b[4m'
		reversed='\u001b[7m'
		#-------------------------------------------#
		green='\u001b[32m'
		blue='\u001b[34m'
		red='\u001b[31m'
		white='\u001b[37m'
		black='\u001b[30m'
		yellow='\u001b[33m'
		magenta='\u001b[35m'
		cyan='\u001b[36m'
		#-------------------------------------------#
		green_light='\u001b[32;1m'
		blue_light='\u001b[34;1m'
		red_light='\u001b[31;1m'
		white_light='\u001b[37;1m'
		yellow_light='\u001b[33;1m'
		magenta_light='\u001b[35;1m'
		cyan_light='\u001b[36;1m'
		#-------------------------------------------#
		bg_black='\u001b[40m'
		bg_red='\u001b[41m'
		bg_green='\u001b[42m'
		bg_yellow='\u001b[43m'
		bg_blue='\u001b[44m'
		bg_magenta='\u001b[45m'
		bg_cyan='\u001b[46m'
		bg_white='\u001b[47m'
		#-------------------------------------------#
		bg_black_light='\u001b[40;1m'
		bg_red_light='\u001b[41;1m'
		bg_green_light='\u001b[42;1m'
		bg_yellow_light='\u001b[43;1m'
		bg_blue_light='\u001b[44;1m'
		bg_magenta_light='\u001b[45;1m'
		bg_cyan_light='\u001b[46;1m'
		bg_white_light='\u001b[47;1m'
		#-------------------------------------------#

		import time, sys, os, random, string, time, re, datetime
		from time import sleep
		from datetime import datetime as dt

		def printProgressBar (iteration, total, prefix = '', suffix = '', decimals = 1, length = 100, fill = cyan+bold+'█', printEnd = "\r"):

		    percent = (bold+magenta+"{0:." + str(decimals) + "f}").format(100 * (iteration / float(total)))
		    filledLength = int(length * iteration // total)
		    bar = fill * filledLength + ' ' * (length - filledLength)
		    print(f'\r{prefix} '+cyan+bold+'|'+reset+f'{bar}| {percent}% {suffix}', end = printEnd)
		    if iteration == total:
		        print()

		items = list(range(0, 57))
		l = len(items)
		def jalan(jum):
		        for i, item in enumerate(items):
		            time.sleep(jum)
		            printProgressBar(i + 1, l, prefix = bold+green+'Loading:'+reset, suffix = bold+magenta+'Complete'+reset, length = 15)

		def timer(start_minute, start_second):
			total_second = start_minute * 60 + start_second
			while total_second:
				mins, secs = divmod(total_second, 60)
				print(cyan+bold+f'{mins:02d}:{secs:02d}', end='\r'+reset)
				time.sleep(1)
				total_second -= 1
		def delay(s):
		    for c in s:
		        sys.stdout.write(c)
		        sys.stdout.flush()
		        time.sleep(0.01)
		    print()
		now=dt.now()
		jam=f"[{bold}{yellow}{now.hour}:{cyan}{now.minute}:{green}{now.second}{reset}]"

		try:
			import bs4
		except:
			delay(bold+cyan+'Memulai Penginstalan....')
			os.system('pip install requests')
			os.system('pip install bs4')

		import requests, json, bs4, string
		from bs4 import BeautifulSoup

		##################
		script='gomine.xyz'
		##################

		#--------------------------------------------------------------------------------------------#
		link_pass='https://controlc.com/b988d863'
		link_status='https://controlc.com/72da75d2'
		status=BeautifulSoup(requests.get(link_status).text, 'html.parser').find('meta')['content']
		status1=BeautifulSoup(requests.get(link_status).text, 'html.parser').find('meta')['content']
		pasd=BeautifulSoup(requests.get(link_pass).text, 'html.parser').find('meta')['content']
		#--------------------------------------------------------------------------------------------#

		try:
			delay(bold+cyan+'MENGECEK PASSWORD...')
			time.sleep(1)
			jalan(0.01)
			cek=open('pass.md', 'r').read()
			if cek == pasd:
				print(bold+green+'PASSWORD TERBACA [√]'+reset)
				time.sleep(1)

		except:
			os.system('clear')
			print(bold+bg_white+black+'          SELAMAT DATANG           '+reset)
			print(bold+magenta+'-----------------------------------')
			print(bold+cyan+'Akses link dan dapatkan password')
			print(bold+magenta+'-----------------------------------')
			print(bold+cyan+'Link : https://controlc.com/b988d863')
			print(bold+magenta+'-----------------------------------'+reset)

			pas=input('\nMasukkan Password : '+magenta+bold)
			time.sleep(1)
			if pas in pasd:
				delay(bold+green+'PASSWORD BENAR [√]'+reset)
				open('pass.md', 'w').writelines(pasd)
				time.sleep(2)
			else:
				delay(bold+red_light+'PASSWORD SALAH [X]'+reset)
				exit()
		#--------------------------------------------------------------------------------------------#
		os.system('clear')
		print(bold+'['+bg_white+bold+blue+'                    '+script+'                      '+reset+bold+']')

		print(bold+blue+'\n██╗  ██╗███████╗██╗     ██╗      ██████╗'+reset+white+bold+"  Saran saya")
		print(bold+red+'██║  ██║██╔════╝██║     ██║     ██╔═══██╗'+reset+bold+white+" Jangan")
		print(bold+cyan+'███████║█████╗  ██║     ██║     ██║   ██║'+reset+bold+white+" Terlalu")
		print(bold+magenta+'██╔══██║██╔══╝  ██║     ██║     ██║   ██║'+reset+bold+white+" Brutal")
		print(bold+yellow+'██║  ██║███████╗███████╗███████╗╚██████╔╝'+reset+bold+white+" Broo")
		print(bold+green+'╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝ ╚═════╝'+reset)

		if 'online' in status:
			print(bold+'STATUS : '+green+'ONLINE'+reset)
		else:
			print(bold+'STATUS : '+red_light+'OFFLINE'+reset)
		print(bold+yellow+'╔═════════════════════════════════════════════════╗')
		print(bold+yellow+' [!] Script ini bersifat illegal')
		print(bold+yellow+' [!] Pembuat tidak bertanggungjawab terhadap apapun')
		print(bold+yellow+' [!] Resiko ditanggung Pengguna')
		print(bold+yellow+'╚═════════════════════════════════════════════════╝')

		print(bold+green+'╔═══════════════════════════════╗')
		delay(bold+green+' [√] Script created by '+magenta+'Don iCe')
		delay(bold+green+' [√] version '+magenta+'Private')
		delay(bold+green+' [√] telegram @lordtrippleg')
		delay(bold+green+' [√] L0rd Tr1ppl3G ')
		print(bold+green+'╚═══════════════════════════════╝')

		print(bold+cyan+'╔══════════════════════════╗')
		print(bold+cyan+'           MENU             ')
		print(bold+cyan+'╚══════════════════════════╝')
		delay(bold+cyan+' [1] Start mining')
		delay(bold+cyan+' [2] Withdraw')
		delay(bold+cyan+' [3] Exit')
		print(bold+cyan+'╚══════════════════════════╝'+reset)

		if 'offline' in status1:
			print(f'{bold}{magenta}>Hub. owner untuk mendapatkan versi terbaru<'+reset)
			exit()
	    #----------------------------------------------------------------------------------------------#
		'''
		baca=open('ua.txt', 'r').read().splitlines()
		acak=random.choice(baca)
		'''
		#------------------------------------------------------#
		ceked=open('data.py', 'r').read()
		#------------------------------------------------------#
		if 'Sudah' in ceked:
			print(reset)
			import data
		else:
			#------------------------------------------------------#
			data1=input(f"{bold}Address TRX (faucetpay.io): {cyan}")
			data2=input(f"Cookie : ")
			ua=input(reset+bold+'User Agent : '+green)
			print(reset)
			#------------------------------------------------------#
			open('data.py', 'w').write(f"save='Sudah'\nAddressTRX='{data1}'\nCookie='{data2}'\nua='{ua}'")
			#------------------------------------------------------#
			import data
		pilih=input(yellow+bold+'Pilih => '+reset)
		if '1' in pilih:
			main1()
		elif '2' in pilih:
			main2()
		elif '3' in pilih:
			exit("Was Exit")
		else:
			print(f"{bold}Silakan pilih nomor 1, 2, atau 3")

	except KeyboardInterrupt:
		print(f"\n{reset}")
		os.system("rm -rf __pycache__")
#	except IndexError:
#		print(f"{bold}Please check your connection VPN!!")

