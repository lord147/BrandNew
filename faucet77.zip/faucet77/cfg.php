<?php

$useragent = "isi sama useragent";

$cookie = "isi cookei";

$urlclaim = "isi urlnya";

//tanda " jangan sampe ilang