<?

$cookie ="xxxxx";