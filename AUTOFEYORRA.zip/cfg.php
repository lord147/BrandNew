<?php

//JANGAN LUPA SUBSCRIBE YzZzTv
//DONT FORGET TO SUBSCRIBE YzZzTv

//email faucetpay tanpa "@gmail.com"
$fp = "xxxx";

$useragent = "xxxx";

$cookie = "xxxx";