<?php

$useragent = "Mozilla/5.0 (Linux; Android 9; JAT-L29) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36";

$cookie = "_gid=GA1.2.2139677143.1631887541; dom3ic8zudi28v8lr6fgphwffqoz0j6c=e3bcb721-b8b2-4112-b6a7-0b3d1caeff73:3:1; ci_session=21692bcf60b7ef6d426e3db7f31bc989600db490; _data_cpc=555-2-1631938875; sb_main_a344467b4521bdefdf86b1cb6e25fc60=1; csrf_cookie_name=a20719fe0eb7a635a48889ab999aff3a; _ga=GA1.2.67613912.1631887541; _gat_gtag_UA_201762265_3=1; _ga_RZYLV5PCX4=GS1.1.1631935191.4.1.1631935463.0; pop_delay_3777=1; sb_count_a344467b4521bdefdf86b1cb6e25fc60=7";